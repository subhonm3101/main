const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 2000;

// Настройка EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware для статических файлов
app.use(express.static(path.join(__dirname, 'public')));

// Middleware для парсинга тела запроса
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Маршруты
app.get('/', (req, res) => {
    console.log('GET запрос на главную страницу');
    res.render('index', {
        title: 'Главная страница',
        message: 'Добро пожаловать на сайт!',
        currentYear: new Date().getFullYear()
    });
});

app.get('/about', (req, res) => {
    console.log('GET запрос на страницу "О нас"');
    res.render('about', {
        title: 'О нас',
        name: 'Иван Иванов',
        age: 30,
        interests: ['Программирование', 'Дизайн', 'Фотография'],
        bio: 'Опытный разработчик с 3-летним опытом работы. Люблю создавать интересные проекты и изучать новые технологии.',
        currentYear: new Date().getFullYear()
    });
});

app.get('/contacts', (req, res) => {
    console.log('GET запрос на страницу "Контакты"');
    res.render('contacts', {
        title: 'Контакты',
        contacts: {
            email: 'info@example.com',
            phone: '+7 (123) 456-78-90',
            github: 'github.com/username'
        },
        currentYear: new Date().getFullYear()
    });
});

app.get('/user/:id', (req, res) => {
    console.log(`GET запрос информации о пользователе с ID: ${req.params.id}`);
    res.send(`Информация о пользователе с ID: ${req.params.id}`);
});

// Запуск сервера
app.listen(port, () => {
    console.log(`Сервер запущен на порту ${port}`);
});